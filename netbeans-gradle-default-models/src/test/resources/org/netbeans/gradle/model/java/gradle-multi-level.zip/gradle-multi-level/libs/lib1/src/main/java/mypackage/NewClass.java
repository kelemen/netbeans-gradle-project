/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mypackage;

/**
 *
 * @author Kelemen Attila
 */
public final class NewClass {
    public static void testMethod() {
        for (int i = 0; i < 5; i++) {
            System.out.println("LINE" + i + ": " + (Math.pow(2, 4) + 5));
        }
    }
}
