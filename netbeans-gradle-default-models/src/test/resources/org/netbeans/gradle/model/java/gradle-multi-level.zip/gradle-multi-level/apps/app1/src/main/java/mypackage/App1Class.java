package mypackage;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Kelemen Attila
 */
public final class App1Class {
    private static final Logger LOGGER = Logger.getLogger(App1Class.class.getName());
    
    private static void testMethod() {
        try {
            new Runnable() {
                @Override
                public void run() {
                    NewClass.testMethod();
                    throw new RuntimeException("Exception in anonymous class.");
                }
            }.run();
        } catch (Throwable ex) { 
            LOGGER.log(Level.SEVERE, "Hello", ex);
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            testMethod();
        }
    }
    
    private static final class NestedClass {
        public void run() {
            throw new RuntimeException("Exception in NestedClass.");
        }
    }    
}
