package mypackage;

import java.util.logging.Level;
import java.util.logging.Logger;

public final class App1Class {
    public static void main(String[] args) {
        System.out.println("gradle-multi-level/mypackage.App1Class");
    }
}
