package testpckg;

import java.nio.charset.*;
import java.nio.file.*;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class App {
    public static void main(String[] args) throws Throwable {
        Path outputPath = args.length > 0 ? Paths.get(args[0]) : Paths.get("build").resolve("output-auto.txt");
        Path dir = outputPath.getParent();

        try {
            String content = args.length > 1 ? args[1] : "Auto-Test-Content";

            Files.createDirectories(dir);
            Files.write(outputPath, content.getBytes(StandardCharsets.UTF_8));
        } finally {
            Files.write(dir.resolve("done.txt"), "DONE".getBytes(StandardCharsets.UTF_8));
        }
    }
}
